const express = require('express');
const router = express.Router();

// Configura il nome utente admin e la password in modo sicuro
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'kilwinning2025'; // Cambia questa o usa una variabile ambiente!

// LOGIN: POST /auth/login
router.post('/login', express.json(), (req, res) => {
    const { username, password } = req.body;
    if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
        req.session.user = { username: ADMIN_USERNAME, ruolo: 'admin' };
        return res.json({ success: true, user: req.session.user });
    }
    res.status(401).json({ success: false, message: 'Credenziali non valide' });
});

// LOGOUT: POST /auth/logout
router.post('/logout', (req, res) => {
    req.session.destroy(() => {
        res.json({ success: true });
    });
});

// SESSION STATUS: GET /auth/me
router.get('/me', (req, res) => {
    if (req.session && req.session.user) {
        res.json({ authenticated: true, user: req.session.user });
    } else {
        res.status(401).json({ authenticated: false });
    }
});

module.exports = router;