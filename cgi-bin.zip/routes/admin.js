const express = require('express');
const path = require('path');
const router = express.Router();

// Middleware di autenticazione per le rotte admin
function requireAuth(req, res, next) {
    if (!req.session || !req.session.user) {
        return res.redirect('/admin?error=login_required');
    }
    next();
}

// Pagina di login admin (non protetta)
router.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../views/admin.html'));
});

// Dashboard principale (protetta)
router.get('/dashboard', requireAuth, (req, res) => {
    res.sendFile(path.join(__dirname, '../views/admin-dashboard.html'));
});

// ===== PAGINE SEPARATE (usano i tuoi file JS originali) =====

// Gestione Tornate - USA admin-tornate.html + admin-tornate.js
router.get('/tornate', requireAuth, (req, res) => {
    res.sendFile(path.join(__dirname, '../views/admin-tornate.html'));
});

// Registra Presenze - USA admin-presenze.html + admin-presenze.js  
router.get('/presenze', requireAuth, (req, res) => {
    res.sendFile(path.join(__dirname, '../views/admin-presenze.html'));
});

// Gestione Fratelli - USA admin-fratelli.html + admin-fratelli.js
router.get('/fratelli', requireAuth, (req, res) => {
    res.sendFile(path.join(__dirname, '../views/admin-fratelli.html'));
});

// Gestione Ruoli - USA admin-ruoli.html + admin-ruoli.js
router.get('/ruoli', requireAuth, (req, res) => {
    res.sendFile(path.join(__dirname, '../views/admin-ruoli.html'));
});

module.exports = router;