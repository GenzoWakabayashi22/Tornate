const express = require('express');
const router = express.Router();
const { db } = require('../config/database');

// GET /api/presenze/tornata/:id - Presenze per una tornata specifica
router.get('/tornata/:id', async (req, res) => {
    try {
        const { id } = req.params;
        
        // Verifica che la tornata esista
        const tornata = await db.getTornataById(id);
        if (!tornata) {
            return res.status(404).json({
                success: false,
                message: 'Tornata non trovata'
            });
        }
        
        // Recupera presenze e ospiti
        const presenze = await db.getPresenzeByTornata(id);
        const ospiti = await db.getOspitiByTornata(id);
        const fratelli = await db.getFratelli();
        
        res.json({
            success: true,
            data: {
                tornata: tornata,
                presenze: presenze,
                ospiti: ospiti,
                fratelli: fratelli
            }
        });
        
    } catch (error) {
        console.error('Errore nel recupero presenze:', error);
        res.status(500).json({
            success: false,
            message: 'Errore nel recupero delle presenze',
            error: error.message
        });
    }
});

// POST /api/presenze/tornata/:id - Registra presenze per una tornata
router.post('/tornata/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { presenze } = req.body;
        
        // Verifica che la tornata esista
        const tornata = await db.getTornataById(id);
        if (!tornata) {
            return res.status(404).json({
                success: false,
                message: 'Tornata non trovata'
            });
        }
        
        // Validazione presenze
        if (!Array.isArray(presenze)) {
            return res.status(400).json({
                success: false,
                message: 'Le presenze devono essere un array'
            });
        }
        
        // Registra le presenze
        await db.registraPresenzeTornata(id, presenze);
        
        res.json({
            success: true,
            message: 'Presenze registrate con successo',
            count: presenze.length
        });
        
    } catch (error) {
        console.error('Errore nella registrazione presenze:', error);
        res.status(500).json({
            success: false,
            message: 'Errore nella registrazione delle presenze',
            error: error.message
        });
    }
});

// GET /api/presenze/ospiti/tornata/:id - Ospiti per una tornata
router.get('/ospiti/tornata/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const ospiti = await db.getOspitiByTornata(id);
        
        res.json({
            success: true,
            data: ospiti
        });
        
    } catch (error) {
        console.error('Errore nel recupero ospiti:', error);
        res.status(500).json({
            success: false,
            message: 'Errore nel recupero degli ospiti',
            error: error.message
        });
    }
});

// POST /api/presenze/ospiti - Aggiungi ospite
router.post('/ospiti', async (req, res) => {
    try {
        const { tornata_id, nome, loggia_provenienza, grado, note } = req.body;
        
        // Validazione
        if (!tornata_id || !nome) {
            return res.status(400).json({
                success: false,
                message: 'Tornata ID e nome ospite sono obbligatori'
            });
        }
        
        const result = await db.addOspite(tornata_id, nome, loggia_provenienza, grado, note);
        
        res.status(201).json({
            success: true,
            message: 'Ospite aggiunto con successo',
            data: {
                id: result.insertId,
                tornata_id,
                nome,
                loggia_provenienza,
                grado,
                note
            }
        });
        
    } catch (error) {
        console.error('Errore nell\'aggiunta ospite:', error);
        res.status(500).json({
            success: false,
            message: 'Errore nell\'aggiunta dell\'ospite',
            error: error.message
        });
    }
});

// PUT /api/presenze/ospiti/:id - Modifica ospite
router.put('/ospiti/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { nome, loggia_provenienza, grado, note } = req.body;
        
        if (!nome) {
            return res.status(400).json({
                success: false,
                message: 'Nome ospite è obbligatorio'
            });
        }
        
        await db.updateOspite(id, nome, loggia_provenienza, grado, note);
        
        res.json({
            success: true,
            message: 'Ospite aggiornato con successo'
        });
        
    } catch (error) {
        console.error('Errore nell\'aggiornamento ospite:', error);
        res.status(500).json({
            success: false,
            message: 'Errore nell\'aggiornamento dell\'ospite',
            error: error.message
        });
    }
});

// DELETE /api/presenze/ospiti/:id - Elimina ospite
router.delete('/ospiti/:id', async (req, res) => {
    try {
        const { id } = req.params;
        
        await db.deleteOspite(id);
        
        res.json({
            success: true,
            message: 'Ospite eliminato con successo'
        });
        
    } catch (error) {
        console.error('Errore nell\'eliminazione ospite:', error);
        res.status(500).json({
            success: false,
            message: 'Errore nell\'eliminazione dell\'ospite',
            error: error.message
        });
    }
});

// GET /api/presenze/statistiche - Statistiche presenze generali
router.get('/statistiche', async (req, res) => {
    try {
        const { anno } = req.query;
        
        const stats = await db.getStatistichePresenze(anno);
        
        res.json({
            success: true,
            data: stats,
            filtro_anno: anno || 'tutti'
        });
        
    } catch (error) {
        console.error('Errore statistiche presenze:', error);
        res.status(500).json({
            success: false,
            message: 'Errore nel recupero delle statistiche',
            error: error.message
        });
    }
});

// GET /api/presenze/fratello/:id - Presenze di un fratello specifico
router.get('/fratello/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { anno } = req.query;
        
        let sql = `
            SELECT t.data, t.tipo, t.location, p.ruolo, p.presente
            FROM presenze p
            JOIN tornate t ON p.tornata_id = t.id
            WHERE p.fratello_id = ?
        `;
        
        const params = [id];
        
        if (anno) {
            sql += ' AND YEAR(t.data) = ?';
            params.push(anno);
        }
        
        sql += ' ORDER BY t.data DESC';
        
        const presenze = await db.executeQuery(sql, params);
        const fratello = await db.getFratelloById(id);
        
        res.json({
            success: true,
            data: {
                fratello: fratello,
                presenze: presenze,
                totale: presenze.length,
                presenti: presenze.filter(p => p.presente).length,
                assenti: presenze.filter(p => !p.presente).length
            }
        });
        
    } catch (error) {
        console.error('Errore presenze fratello:', error);
        res.status(500).json({
            success: false,
            message: 'Errore nel recupero delle presenze del fratello',
            error: error.message
        });
    }
});

module.exports = router;