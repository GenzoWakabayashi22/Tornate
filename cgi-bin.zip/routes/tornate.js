const express = require('express');
const router = express.Router();
const { db } = require('../config/database');

// GET /api/tornate - Lista tutte le tornate con filtri opzionali
router.get('/', async (req, res) => {
    try {
        const { anno, tipo_loggia, stato } = req.query;
        
        const filtri = {};
        if (anno) filtri.anno = anno;
        if (tipo_loggia) filtri.tipo_loggia = tipo_loggia;
        if (stato) filtri.stato = stato;
        
        const tornate = await db.getTornate(filtri);
        
        res.json({
            success: true,
            data: tornate,
            count: tornate.length
        });
        
    } catch (error) {
        console.error('Errore nel recupero tornate:', error);
        res.status(500).json({
            success: false,
            message: 'Errore nel recupero delle tornate',
            error: error.message
        });
    }
});

// GET /api/tornate/calendario/:anno - Tornate per calendario
router.get('/calendario/:anno', async (req, res) => {
    try {
        const { anno } = req.params;
        const { mese } = req.query;
        
        const tornate = await db.getTornatePerCalendario(anno, mese);
        
        // Organizza per mese per il frontend
        const calendario = {};
        tornate.forEach(tornata => {
            const data = new Date(tornata.data);
            const meseKey = data.getMonth() + 1; // 1-12
            
            if (!calendario[meseKey]) {
                calendario[meseKey] = [];
            }
            
            calendario[meseKey].push({
                ...tornata,
                data_formatted: data.toLocaleDateString('it-IT')
            });
        });
        
        res.json({
            success: true,
            anno: parseInt(anno),
            calendario: calendario,
            totale_tornate: tornate.length
        });
        
    } catch (error) {
        console.error('Errore calendario tornate:', error);
        res.status(500).json({
            success: false,
            message: 'Errore nel recupero del calendario',
            error: error.message
        });
    }
});

// GET /api/tornate/:id - Dettagli singola tornata
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        
        const tornata = await db.getTornataById(id);
        
        if (!tornata) {
            return res.status(404).json({
                success: false,
                message: 'Tornata non trovata'
            });
        }
        
        // Recupera anche le presenze per questa tornata
        const presenze = await db.getPresenzeByTornata(id);
        
        res.json({
            success: true,
            data: {
                ...tornata,
                presenze: presenze
            }
        });
        
    } catch (error) {
        console.error('Errore nel recupero tornata:', error);
        res.status(500).json({
            success: false,
            message: 'Errore nel recupero della tornata',
            error: error.message
        });
    }
});

// POST /api/tornate - Crea nuova tornata (solo admin)
router.post('/', async (req, res) => {
    try {
        const tornataData = req.body;
        
        // Validazione base
        if (!tornataData.data) {
            return res.status(400).json({
                success: false,
                message: 'Data della tornata è obbligatoria'
            });
        }
        
        // Converti stringhe vuote in null per il database
        Object.keys(tornataData).forEach(key => {
            if (tornataData[key] === '') {
                tornataData[key] = null;
            }
        });
        
        const result = await db.addTornata(tornataData);
        
        res.status(201).json({
            success: true,
            message: 'Tornata creata con successo',
            data: {
                id: result.insertId,
                ...tornataData
            }
        });
        
    } catch (error) {
        console.error('Errore nella creazione tornata:', error);
        res.status(500).json({
            success: false,
            message: 'Errore nella creazione della tornata',
            error: error.message
        });
    }
});

// PUT /api/tornate/:id - Aggiorna tornata (solo admin)
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const tornataData = req.body;
        
        // Verifica che la tornata esista
        const tornataEsistente = await db.getTornataById(id);
        if (!tornataEsistente) {
            return res.status(404).json({
                success: false,
                message: 'Tornata non trovata'
            });
        }
        
        // Converti stringhe vuote in null
        Object.keys(tornataData).forEach(key => {
            if (tornataData[key] === '') {
                tornataData[key] = null;
            }
        });
        
        await db.updateTornata(id, tornataData);
        
        // Recupera la tornata aggiornata
        const tornataAggiornata = await db.getTornataById(id);
        
        res.json({
            success: true,
            message: 'Tornata aggiornata con successo',
            data: tornataAggiornata
        });
        
    } catch (error) {
        console.error('Errore aggiornamento tornata:', error);
        res.status(500).json({
            success: false,
            message: 'Errore nell\'aggiornamento della tornata',
            error: error.message
        });
    }
});

// DELETE /api/tornate/:id - Elimina tornata (solo admin)
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        
        // Verifica che la tornata esista
        const tornata = await db.getTornataById(id);
        if (!tornata) {
            return res.status(404).json({
                success: false,
                message: 'Tornata non trovata'
            });
        }
        
        // Verifica se ci sono presenze associate
        const presenze = await db.getPresenzeByTornata(id);
        if (presenze.length > 0) {
            return res.status(400).json({
                success: false,
                message: 'Impossibile eliminare: tornata con presenze registrate',
                presenze_count: presenze.length
            });
        }
        
        await db.deleteTornata(id);
        
        res.json({
            success: true,
            message: 'Tornata eliminata con successo'
        });
        
    } catch (error) {
        console.error('Errore eliminazione tornata:', error);
        res.status(500).json({
            success: false,
            message: 'Errore nell\'eliminazione della tornata',
            error: error.message
        });
    }
});

// GET /api/tornate/stats/introduzioni - Statistiche chi ha introdotto discussioni
router.get('/stats/introduzioni', async (req, res) => {
    try {
        const { anno } = req.query;
        
        const stats = await db.getStatisticheIntroduzioni(anno);
        
        res.json({
            success: true,
            data: stats,
            filtro_anno: anno || 'tutti'
        });
        
    } catch (error) {
        console.error('Errore statistiche introduzioni:', error);
        res.status(500).json({
            success: false,
            message: 'Errore nel recupero delle statistiche',
            error: error.message
        });
    }
});

// PATCH /api/tornate/:id/stato - Cambia solo lo stato della tornata
router.patch('/:id/stato', async (req, res) => {
    try {
        const { id } = req.params;
        const { stato } = req.body;
        
        const statiValidi = ['programmata', 'completata', 'annullata'];
        if (!statiValidi.includes(stato)) {
            return res.status(400).json({
                success: false,
                message: 'Stato non valido. Valori ammessi: ' + statiValidi.join(', ')
            });
        }
        
        await db.updateTornata(id, { stato });
        
        const tornataAggiornata = await db.getTornataById(id);
        
        res.json({
            success: true,
            message: `Stato cambiato in: ${stato}`,
            data: tornataAggiornata
        });
        
    } catch (error) {
        console.error('Errore cambio stato:', error);
        res.status(500).json({
            success: false,
            message: 'Errore nel cambio di stato',
            error: error.message
        });
    }
});

module.exports = router;