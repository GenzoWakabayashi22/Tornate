// admin.js - Gestione login area amministrativa

document.addEventListener('DOMContentLoaded', function() {
    // Controlla se già autenticato
    checkAuthStatus();
    
    // Setup form login
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    // Mostra errori dalla URL
    showUrlErrors();
});

// Controlla stato autenticazione
async function checkAuthStatus() {
    try {
        const response = await fetch('/auth/me');
        const result = await response.json();
        
        if (result.success) {
            // Utente già autenticato, reindirizza al dashboard
            redirectToDashboard(result.user.ruolo);
        }
    } catch (error) {
        // Non autenticato, rimani sulla pagina login
        console.log('Non autenticato');
    }
}

// Gestisce submit del form login
async function handleLogin(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const credentials = {
        username: formData.get('username'),
        password: formData.get('password')
    };
    
    // Validazione base
    if (!credentials.username || !credentials.password) {
        showError('Inserisci username e password');
        return;
    }
    
    // Disabilita form durante il login
    setFormLoading(true);
    
    try {
        const response = await fetch('/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(credentials)
        });
        
        const result = await response.json();
        
        if (result.success) {
            showSuccess('Login effettuato con successo!');
            
            // Attendi un momento prima del redirect
            setTimeout(() => {
                redirectToDashboard(result.user.ruolo);
            }, 1000);
            
        } else {
            throw new Error(result.message || 'Login fallito');
        }
        
    } catch (error) {
        console.error('Errore login:', error);
        showError('Errore login: ' + error.message);
    } finally {
        setFormLoading(false);
    }
}

// Reindirizza al dashboard appropriato
function redirectToDashboard(ruolo) {
    switch (ruolo) {
        case 'admin':
            window.location.href = '/admin/dashboard';    // ← NUOVO DASHBOARD
            break;
        case 'segretario':
            window.location.href = '/admin/dashboard?section=presenze';  // ← DIRETTO ALLE PRESENZE
            break;
        default:
            window.location.href = '/admin/dashboard';    // ← DASHBOARD GENERALE
    }
}

// Imposta stato di caricamento del form
function setFormLoading(loading) {
    const form = document.getElementById('loginForm');
    const submitBtn = form.querySelector('button[type="submit"]');
    const inputs = form.querySelectorAll('input');
    
    if (loading) {
        submitBtn.disabled = true;
        submitBtn.textContent = 'Accesso in corso...';
        inputs.forEach(input => input.disabled = true);
    } else {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Login';
        inputs.forEach(input => input.disabled = false);
    }
}

// Mostra errori dalla URL
function showUrlErrors() {
    const urlParams = new URLSearchParams(window.location.search);
    const error = urlParams.get('error');
    
    if (error === 'login_required') {
        showError('Accesso richiesto. Effettua il login per continuare.');
    }
}

// Utility per mostrare messaggi
function showSuccess(message) {
    showMessage(message, 'success');
}

function showError(message) {
    showMessage(message, 'error');
}

function showMessage(message, type) {
    // Rimuovi messaggi esistenti
    const existing = document.querySelector('.message-toast');
    if (existing) {
        existing.remove();
    }
    
    // Crea toast
    const toast = document.createElement('div');
    toast.className = `message-toast ${type}`;
    toast.innerHTML = `
        <div class="toast-content">
            <span class="toast-icon">${type === 'success' ? '✅' : '❌'}</span>
            <span class="toast-text">${message}</span>
        </div>
    `;
    
    // Aggiungi stili
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 1000;
        background: ${type === 'success' ? '#d4edda' : '#f8d7da'};
        color: ${type === 'success' ? '#155724' : '#721c24'};
        border: 1px solid ${type === 'success' ? '#c3e6cb' : '#f5c6cb'};
        border-radius: 8px;
        padding: 15px 20px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        animation: slideInRight 0.3s ease-out;
        max-width: 300px;
    `;
    
    // Aggiungi al DOM
    document.body.appendChild(toast);
    
    // Rimuovi automaticamente dopo 5 secondi
    setTimeout(() => {
        if (toast && toast.parentNode) {
            toast.style.animation = 'slideOutRight 0.3s ease-in';
            setTimeout(() => toast.remove(), 300);
        }
    }, 5000);
    
    // Click per chiudere
    toast.addEventListener('click', () => {
        toast.style.animation = 'slideOutRight 0.3s ease-in';
        setTimeout(() => toast.remove(), 300);
    });
}

// Aggiungi CSS per animazioni
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    .toast-content {
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .toast-icon {
        font-size: 16px;
    }
    
    .toast-text {
        flex: 1;
        font-weight: 500;
    }
    
    .message-toast {
        cursor: pointer;
        transition: transform 0.2s;
    }
    
    .message-toast:hover {
        transform: translateX(-5px);
    }
`;

document.head.appendChild(style);