// Variabili globali
let fratelliData = [];
let filteredData = [];
let currentEditId = null;

// Lista ruoli aggiornata con icone corrette
const ruoliDisponibili = [
    { value: '', text: '✅ Nessun ruolo fisso' },
    { value: 'Ven.mo Maestro', text: '👑 Ven.mo Maestro' },
    { value: 'Primo Sorvegliante', text: '🔨 Primo Sorvegliante' },
    { value: 'Secondo Sorvegliante', text: '🔨 Secondo Sorvegliante' },
    { value: 'Oratore', text: '📖 Oratore' },
    { value: 'Segretario', text: '📜 Segretario' },
    { value: 'Tesoriere', text: '💰 Tesoriere' },
    { value: 'Copritore', text: '⚔️ Copritore' },
    { value: 'Maestro Cerimonie', text: '🎯 Maestro Cerimonie' },
    { value: 'Esperto', text: '🪢 Esperto' },
    { value: 'Compagno d\'Armonia', text: '🎼 Compagno d\'Armonia' },
    { value: 'Compagno d\'Arte', text: '🔨 Compagno d\'Arte' },
    { value: 'Primo Diacono', text: '🕊️ Primo Diacono' },
    { value: 'Secondo Diacono', text: '🕊️ Secondo Diacono' },
    { value: 'Ospedaliere', text: '🏥 Ospedaliere' },
    { value: 'Narratore Rituali', text: '📢 Narratore Rituali' },
    { value: 'Bibliotecario', text: '📚 Bibliotecario' },
    { value: 'Maestro di Casa', text: '🏡 Maestro di Casa' },
    { value: 'Altro', text: '➕ Altro' }
];

// Inizializzazione
document.addEventListener('DOMContentLoaded', function() {
    loadFratelli();
    setupEventListeners();
    populateRuoliSelect();
});

// Popola il select dei ruoli
function populateRuoliSelect() {
    const select = document.getElementById('cariche_fisse');
    if (!select) return;
    
    // Pulisci le opzioni esistenti
    select.innerHTML = '';
    
    // Aggiungi le nuove opzioni
    ruoliDisponibili.forEach(ruolo => {
        const option = document.createElement('option');
        option.value = ruolo.value;
        option.textContent = ruolo.text;
        select.appendChild(option);
    });
}

// Setup event listeners
function setupEventListeners() {
    // Form submit
    document.getElementById('fratelloForm').addEventListener('submit', handleFormSubmit);
}

// Carica lista fratelli
async function loadFratelli() {
    showLoading(true);
    
    try {
        const response = await fetch('/api/fratelli');
        const data = await response.json();
        
        if (Array.isArray(data)) {
            fratelliData = data.sort((a, b) => a.nome.localeCompare(b.nome));
            filteredData = [...fratelliData];
            renderFratelliTable();
            updateStats();
        } else {
            throw new Error('Formato dati non valido');
        }
    } catch (error) {
        console.error('Errore caricamento fratelli:', error);
        showError('Errore nel caricamento dei fratelli: ' + error.message);
    } finally {
        showLoading(false);
    }
}

// Applica filtri
function applicaFiltri() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const gradoFiltro = document.getElementById('filtroGrado').value;
    
    filteredData = fratelliData.filter(fratello => {
        // Filtro per nome
        const matchNome = fratello.nome.toLowerCase().includes(searchTerm);
        
        // Filtro per grado
        const matchGrado = !gradoFiltro || fratello.grado === gradoFiltro;
        
        return matchNome && matchGrado;
    });
    
    renderFratelliTable();
}

// Reset filtri
function resetFiltri() {
    document.getElementById('searchInput').value = '';
    document.getElementById('filtroGrado').value = '';
    filteredData = [...fratelliData];
    renderFratelliTable();
}

// Renderizza tabella fratelli
function renderFratelliTable() {
    const tbody = document.getElementById('fratelliTableBody');
    const tableContainer = document.getElementById('tableContainer');
    const emptyState = document.getElementById('emptyState');
    
    tbody.innerHTML = '';
    
    if (filteredData.length === 0) {
        tableContainer.style.display = 'none';
        emptyState.style.display = 'block';
        return;
    }
    
    tableContainer.style.display = 'block';
    emptyState.style.display = 'none';
    
    filteredData.forEach(fratello => {
        const row = document.createElement('tr');
        
        // Badge grado
        const gradoBadgeClass = `grado-${fratello.grado.toLowerCase()}`;
        
        // Trova l'icona corretta per il ruolo fisso
        let ruoloDisplay = '';
        if (fratello.cariche_fisse) {
            const ruoloInfo = ruoliDisponibili.find(r => r.value === fratello.cariche_fisse);
            if (ruoloInfo) {
                ruoloDisplay = `<span class="ruolo-fisso">${ruoloInfo.text}</span>`;
            } else {
                ruoloDisplay = `<span class="ruolo-fisso">📋 ${fratello.cariche_fisse}</span>`;
            }
        } else {
            ruoloDisplay = '<span style="color: #999;">Nessuno</span>';
        }
        
        row.innerHTML = `
            <td>
                <strong>${fratello.nome}</strong>
            </td>
            <td>
                <span class="grado-badge ${gradoBadgeClass}">
                    ${fratello.grado}
                </span>
            </td>
            <td>
                ${ruoloDisplay}
            </td>
            <td>
                ${fratello.cariche || '<span style="color: #999;">Nessuna</span>'}
            </td>
            <td>
                <div class="action-buttons">
                    <button class="btn btn-primary" onclick="editFratello(${fratello.id})" title="Modifica">
                        ✏️ Modifica
                    </button>
                    <button class="btn btn-danger" onclick="deleteFratello(${fratello.id}, '${fratello.nome}')" title="Elimina">
                        🗑️ Elimina
                    </button>
                </div>
            </td>
        `;
        
        tbody.appendChild(row);
    });
}

// Aggiorna statistiche
function updateStats() {
    const total = fratelliData.length;
    const maestri = fratelliData.filter(f => f.grado === 'Maestro').length;
    const compagni = fratelliData.filter(f => f.grado === 'Compagno').length;
    const apprendisti = fratelliData.filter(f => f.grado === 'Apprendista').length;
    const conRuoli = fratelliData.filter(f => f.cariche_fisse).length;
    
    document.getElementById('totalFratelli').textContent = total;
    document.getElementById('totalMaestri').textContent = maestri;
    document.getElementById('totalCompagni').textContent = compagni;
    document.getElementById('totalApprendisti').textContent = apprendisti;
    document.getElementById('totalConRuoli').textContent = conRuoli;
}

// Apri modal
function openModal(mode, fratelloId = null) {
    const modal = document.getElementById('fratelloModal');
    const modalTitle = document.getElementById('modalTitle');
    const form = document.getElementById('fratelloForm');
    
    currentEditId = fratelloId;
    
    if (mode === 'nuovo') {
        modalTitle.textContent = 'Nuovo Fratello';
        form.reset();
        // Ripopola il select dopo il reset
        populateRuoliSelect();
    } else if (mode === 'modifica' && fratelloId) {
        modalTitle.textContent = 'Modifica Fratello';
        populateRuoliSelect(); // Assicurati che il select sia popolato
        loadFratelloInForm(fratelloId);
    }
    
    modal.style.display = 'block';
}

// Chiudi modal
function closeModal() {
    const modal = document.getElementById('fratelloModal');
    modal.style.display = 'none';
    currentEditId = null;
}

// Carica fratello nel form
function loadFratelloInForm(fratelloId) {
    const fratello = fratelliData.find(f => f.id == fratelloId);
    if (!fratello) return;
    
    document.getElementById('nome').value = fratello.nome || '';
    document.getElementById('grado').value = fratello.grado || '';
    document.getElementById('cariche_fisse').value = fratello.cariche_fisse || '';
    document.getElementById('cariche').value = fratello.cariche || '';
}

// Handle form submit
async function handleFormSubmit(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const fratelloData = Object.fromEntries(formData.entries());
    
    // Converti stringhe vuote in null
    Object.keys(fratelloData).forEach(key => {
        if (fratelloData[key] === '') {
            fratelloData[key] = null;
        }
    });
    
    try {
        let url = '/api/fratelli';
        let method = 'POST';
        
        if (currentEditId) {
            url += '/' + currentEditId;
            method = 'PUT';
        }
        
        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(fratelloData)
        });
        
        const result = await response.json();
        
        if (result.success) {
            showSuccess(result.message);
            closeModal();
            loadFratelli(); // Ricarica tabella
        } else {
            throw new Error(result.message || 'Errore nel salvataggio');
        }
        
    } catch (error) {
        console.error('Errore salvataggio fratello:', error);
        showError('Errore nel salvataggio: ' + error.message);
    }
}

// Modifica fratello
function editFratello(id) {
    openModal('modifica', id);
}

// Elimina fratello
async function deleteFratello(id, nome) {
    // Controllo di sicurezza
    const confirmed = confirm(`⚠️ ATTENZIONE!\n\nSei sicuro di voler eliminare il fratello "${nome}"?\n\nQuesta azione:\n- Rimuoverà TUTTE le sue presenze\n- Rimuoverà il suo ruolo fisso\n- NON può essere annullata\n\nDigita "ELIMINA" per confermare.`);
    
    if (!confirmed) return;
    
    // Secondo livello di conferma
    const confirmText = prompt(`Per confermare l'eliminazione di "${nome}", digita esattamente: ELIMINA`);
    
    if (confirmText !== 'ELIMINA') {
        showError('Eliminazione annullata - testo di conferma non corretto');
        return;
    }
    
    try {
        const response = await fetch(`/api/fratelli/${id}`, {
            method: 'DELETE'
        });
        
        const result = await response.json();
        
        if (result.success) {
            showSuccess(`Fratello "${nome}" eliminato con successo`);
            loadFratelli(); // Ricarica tabella
        } else {
            throw new Error(result.message || 'Errore nell\'eliminazione');
        }
        
    } catch (error) {
        console.error('Errore eliminazione fratello:', error);
        showError('Errore nell\'eliminazione: ' + error.message);
    }
}

// Utility functions
function showLoading(show) {
    const loading = document.getElementById('loadingFratelli');
    const tableContainer = document.getElementById('tableContainer');
    const emptyState = document.getElementById('emptyState');
    
    if (show) {
        loading.style.display = 'block';
        tableContainer.style.display = 'none';
        emptyState.style.display = 'none';
    } else {
        loading.style.display = 'none';
    }
}

function showSuccess(message) {
    alert('✅ ' + message);
}

function showError(message) {
    alert('❌ ' + message);
}

// Gestione click fuori dal modal
window.onclick = function(event) {
    const modal = document.getElementById('fratelloModal');
    if (event.target == modal) {
        closeModal();
    }
}