document.addEventListener('DOMContentLoaded', async () => {
    const userId = sessionStorage.getItem('fratello_id'); // o recuperalo da HTML/URL

    if (!userId) {
        console.error("🛑 Nessun fratello ID trovato nella sessione");
        return;
    }

    try {
        const response = await fetch(`/api/fratelli/${userId}/tornate`);
        const tornate = await response.json();

        const tornateContainer = document.getElementById('tornate-list');
        if (!tornateContainer) {
            console.error("❌ Contenitore tornate non trovato nel DOM");
            return;
        }

        if (!tornate.length) {
            tornateContainer.innerHTML = `<p>Nessuna tornata programmata.</p>`;
            return;
        }

        tornate.forEach(t => {
            const card = document.createElement('div');
            card.className = 'tornata-card';
            card.innerHTML = `
                <h3>${t.titolo} - ${t.data}</h3>
                <p><strong>Ora:</strong> ${t.ora}</p>
                <p><strong>Luogo:</strong> ${t.location}</p>
                <p><strong>Tipo:</strong> ${t.tipo}</p>
                <p><strong>Stato:</strong> ${t.stato}</p>
                ${t.presenza_confermata !== null ? `<p>Presenza: ${t.presenza_confermata ? '✔️' : '❌'}</p>` : ''}
            `;
            tornateContainer.appendChild(card);
        });

    } catch (err) {
        console.error("❌ Errore nel caricamento tornate:", err);
    }
});