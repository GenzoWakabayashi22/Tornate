const express = require('express');
const path = require('path');
const cors = require('cors');
const session = require('express-session');
const bcrypt = require('bcryptjs');
require('dotenv').config();

// Importa la configurazione database
const { testConnection, db } = require('./config/database');


const app = express();

// ========== MIDDLEWARE BASE ==========
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Configurazione sessioni PERSISTENTI
app.use(session({
    secret: process.env.SESSION_SECRET || 'kilwinning_presenze_secret_2025',
    resave: false,
    saveUninitialized: false,
    name: 'kilwinning_session', // Nome specifico
    cookie: {
        secure: false, // HTTP per ora (non HTTPS)
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000, // 24 ore
        sameSite: 'lax' // Permette navigazione tra pagine
    }
}));
// ========== AREA ADMIN (modulare) ==========
app.use('/admin', require('./routes/admin'));
app.use('/auth', require('./routes/auth'));

// ========== API STATUS E TEST ==========
app.get('/api/status', async (req, res) => {
    const dbStatus = await testConnection();
    res.json({ 
        status: 'online', 
        app: 'Presenze Kilwinning',
        version: '1.0.0',
        database: dbStatus ? 'connesso' : 'disconnesso',
        timestamp: new Date().toISOString()
    });
});

app.get('/api/test', (req, res) => {
    res.json({ 
        message: 'Server funzionante!',
        environment: process.env.NODE_ENV || 'development',
        database_configured: !!(process.env.DB_HOST && process.env.DB_NAME)
    });
});

// ========== API FRATELLI ==========
app.get('/api/fratelli/:id/tornate', async (req, res) => {
    const fratelloId = parseInt(req.params.id);
    const limit = parseInt(req.query.limit) || 3;

    try {
        const tornate = await db.getProssimeTornate(fratelloId, limit);
        res.json(tornate);
    } catch (error) {
        console.error('❌ ERRORE API tornate future:', error);
        res.status(500).json({ error: 'Errore nel recupero delle tornate future' });
    }
});
// ========== API TORNATE - DINAMICA CON LIMITE ==========
app.get('/api/fratelli/:id/tornate', async (req, res) => {
    const fratelloId = req.params.id;
    const limit = parseInt(req.query.limit) || 3;

    console.log(`🚀 API TORNATE → Fratello ID: ${fratelloId} | LIMIT: ${limit}`);

    try {
        const query = `
            SELECT 
                t.id,
                t.data,
                t.orario_inizio,
                t.discussione,
                t.location,
                t.tipo,
                t.stato,
                t.cena,
                t.costo_cena,
                t.note,
                f.nome as chi_introduce_nome,
                IFNULL(p.presente, NULL) as presenza_confermata
            FROM tornate t
            LEFT JOIN fratelli f ON t.chi_introduce = f.id
            LEFT JOIN presenze p ON t.id = p.tornata_id AND p.fratello_id = ?
            WHERE t.data >= CURDATE()
            ORDER BY t.data ASC
            LIMIT ?
        `;

        const results = await db.executeQuery(query, [fratelloId, limit]);

        console.log(`✅ Trovate ${results.length} tornate:`);
        results.forEach(t => {
            console.log(`📆 ${t.data} – ${t.discussione || 'Senza titolo'} (${t.tipo})`);
        });

        const tornate = results.map(t => ({
            id: t.id,
            data: t.data,
            ora: t.orario_inizio || '19:30',
            titolo: t.discussione || 'Tornata',
            descrizione: t.location || 'Tolfa',
            tipo: t.tipo || 'ordinaria',
            location: t.location || 'Tolfa',
            stato: t.stato || 'programmata',
            cena: t.cena || 0,
            costo_cena: t.costo_cena || null,
            chi_introduce: t.chi_introduce_nome || null,
            note: t.note || null,
            presenza_confermata: t.presenza_confermata
        }));

        return res.json(tornate);

    } catch (error) {
        console.error('❌ ERRORE DATABASE:', error);
        return res.status(500).json({
            success: false,
            message: 'Errore caricamento tornate',
            error: error.message,
            tornate: []
        });
    }
});
// ========== API STATISTICHE - DA IMPLEMENTARE CON DATABASE ==========
app.get('/api/fratelli/:id/statistiche', async (req, res) => {
    console.log(`📊 API Statistiche - Fratello ID: ${req.params.id}`);
    
    try {
        // Query per statistiche reali dal database
        const stats = await db.executeQuery(`
            SELECT 
                COUNT(DISTINCT t.id) as totali_tornate,
                COUNT(DISTINCT CASE WHEN p.presente = 1 THEN t.id END) as presenze_count
            FROM tornate t
            LEFT JOIN presenze p ON t.id = p.tornata_id AND p.fratello_id = ?
            WHERE YEAR(t.data) = 2025 AND t.data <= CURDATE()
        `, [req.params.id]);
        
        const totaleTornate = stats[0]?.totali_tornate || 0;
        const presenzeCount = stats[0]?.presenze_count || 0;
        const percentuale = totaleTornate > 0 ? Math.round((presenzeCount / totaleTornate) * 100) : 0;
        
        res.json({
            totaliTornate: totaleTornate,
            presenzeCount: presenzeCount,
            percentuale: percentuale
        });
        
    } catch (error) {
        console.error('❌ Errore statistiche:', error);
        // Fallback temporaneo
        res.json({
            totaliTornate: 5,
            presenzeCount: 4,
            percentuale: 80
        });
    }
});

// ========== API PRESENZA - DA IMPLEMENTARE CON DATABASE ==========
app.post('/api/fratelli/:id/presenza', async (req, res) => {
    try {
        const { id } = req.params;
        const { tornataId, presente } = req.body;
        
        console.log(`✅ Conferma presenza: Fratello ${id}, Tornata ${tornataId}, Presente: ${presente}`);
        
        // TODO: Implementare salvataggio reale nel database
        // await db.executeQuery(`
        //     INSERT INTO presenze (fratello_id, tornata_id, presente, data_conferma)
        //     VALUES (?, ?, ?, NOW())
        //     ON DUPLICATE KEY UPDATE presente = ?, data_conferma = NOW()
        // `, [id, tornataId, presente ? 1 : 0, presente ? 1 : 0]);
        
        res.json({ 
            success: true, 
            message: `Presenza ${presente ? 'confermata' : 'rimossa'} con successo` 
        });
        
    } catch (error) {
        console.error('❌ Errore API presenza:', error);
        res.status(500).json({ 
            success: false, 
            error: 'Errore nel salvataggio della presenza' 
        });
    }
});

// ========== ROUTE AREA FRATELLI ==========
app.get('/fratelli/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'views/fratelli/login.html'));
});

app.get('/fratelli/dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'views/fratelli/dashboard.html'));
});

app.get('/fratelli/tornate', (req, res) => {
    res.sendFile(path.join(__dirname, 'views/fratelli/tornate.html'));
});

app.get('/fratelli/lavori', (req, res) => {
    res.sendFile(path.join(__dirname, 'views/fratelli/lavori.html'));
});

app.get('/fratelli/presenze', (req, res) => {
    res.sendFile(path.join(__dirname, 'views/fratelli/presenze.html'));
});

app.get('/fratelli/profilo', (req, res) => {
    res.sendFile(path.join(__dirname, 'views/fratelli/profilo.html'));
});

// ========== HOMEPAGE ==========
app.get('/', (req, res) => {
    res.send(`
        <!DOCTYPE html>
        <html lang="it">
        <head>
            <title>Presenze Kilwinning</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                body { 
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    margin: 0;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    min-height: 100vh;
                    display: flex;
                    flex-direction: column;
                    justify-content: center;
                    align-items: center;
                    color: white;
                }
                .container {
                    text-align: center;
                    background: rgba(255,255,255,0.1);
                    padding: 40px;
                    border-radius: 20px;
                    backdrop-filter: blur(10px);
                    box-shadow: 0 8px 32px rgba(0,0,0,0.2);
                }
                h1 { font-size: 3em; margin-bottom: 20px; }
                .status { color: #00ff88; font-weight: bold; font-size: 1.2em; margin-bottom: 30px; }
                .nav-btn {
                    display: inline-block;
                    margin: 10px;
                    padding: 15px 30px;
                    background: rgba(255,255,255,0.2);
                    color: white;
                    text-decoration: none;
                    border-radius: 10px;
                    border: 2px solid rgba(255,255,255,0.3);
                    transition: all 0.3s;
                    font-weight: bold;
                }
                .nav-btn:hover {
                    background: rgba(255,255,255,0.3);
                    transform: translateY(-2px);
                }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>🏛️ Presenze Kilwinning</h1>
                <p class="status">✅ Sistema Online e Funzionante</p>
                <div>
                    <a href="/admin" class="nav-btn">🔐 Area Admin</a>
                    <a href="/fratelli/login" class="nav-btn">👥 Area Fratelli</a>
                    <a href="/api/status" class="nav-btn">📡 Status Sistema</a>
                </div>
                <p style="margin-top: 30px; opacity: 0.8;">
                    Sistema di gestione presenze per la R∴L∴ Kilwinning
                </p>
            </div>
        </body>
        </html>
    `);
});

// ========== ERROR HANDLING ==========
app.get('*', (req, res) => {
    res.status(404).send(`
        <h1>404 - Pagina Non Trovata</h1>
        <p><a href="/">← Torna alla Home</a></p>
    `);
});

// ========== AVVIO SERVER ==========
(async () => {
    try {
        const dbOk = await testConnection();
        if (!dbOk) throw new Error('❌ Connessione al DB fallita.');

        const PORT = process.env.PORT || 3000;

        app.listen(PORT, () => {
            console.log(`🚀 Server Presenze Kilwinning avviato su porta ${PORT}`);
            console.log(`📍 Ambiente: ${process.env.NODE_ENV || 'development'}`);
            console.log(`⏰ Avvio: ${new Date().toLocaleString('it-IT')}`);
        });

    } catch (err) {
        console.error('💥 CRITICAL ERROR DURANTE AVVIO SERVER:', err);
        process.exit(1); // termina il processo
    }
})();